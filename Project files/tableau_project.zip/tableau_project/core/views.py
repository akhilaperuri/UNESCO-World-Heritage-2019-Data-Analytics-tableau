from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User


# ---------------- PUBLIC ----------------

def home(request):
    return render(request, 'home.html')


# ---------------- AUTH ----------------

def login_view(request):
    form = AuthenticationForm(request, data=request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard_home')

    return render(request, 'login.html', {'form': form})


def register(request):
    form = UserCreationForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('login')

    return render(request, 'register.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


# ---------------- DASHBOARD ----------------

@login_required
def dashboard_home(request):
    return render(request, 'dashboard/dashboard_home.html')


@login_required
def admin_panel(request):

    if not request.user.is_superuser:
        return redirect('dashboard_home')

    users = User.objects.all()
    return render(request, 'dashboard/admin_panel.html', {'users': users})


@login_required
def toggle_user(request, user_id):

    if not request.user.is_superuser:
        return redirect('dashboard_home')

    user = get_object_or_404(User, id=user_id)
    user.is_active = not user.is_active
    user.save()

    return redirect('admin_panel')






