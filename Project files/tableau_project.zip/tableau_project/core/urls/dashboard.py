from django.urls import path
from core import views

urlpatterns = [
    path('', views.dashboard_home, name='dashboard_home'),
    path('Dashboard/admin/', views.admin_panel, name='admin_panel'),
    path('toggle-user/<int:user_id>/', views.toggle_user, name='toggle_user'),
]
